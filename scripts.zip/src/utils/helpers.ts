import type { Lead, Reminder } from '../types.ts';

// Clean phone number for tel: or wa.me/ links
export function cleanPhoneForWhatsApp(phone: string): string {
  const digits = String(phone || '').replace(/[^0-9]/g, '');
  if (!digits) return '';
  if (digits.length === 10) return `1${digits}`;
  return digits;
}

export function renderWhatsAppTemplate(template: string, lead: Lead): string {
  return template
    .replace(/\{\{\s*Business Name\s*\}\}/gi, lead.businessName || 'there')
    .replace(/\{\{\s*City\s*\}\}/gi, lead.city || 'your area')
    .replace(/\{\{\s*Niche\s*\}\}/gi, lead.niche || 'business')
    .replace(/\{\{\s*Rating\s*\}\}/gi, lead.rating || '5.0')
    .replace(/\{\{\s*Reviews\s*\}\}/gi, lead.reviews || 'many')
    .replace(/\{\{\s*Phone\s*\}\}/gi, lead.phone || '');
}

// Build a 1-click Google Calendar event creation URL
export function buildGoogleCalendarUrl(params: {
  title: string;
  details: string;
  location?: string;
  startIso: string;
  durationMinutes?: number;
}): string {
  const start = new Date(params.startIso);
  const end = new Date(start.getTime() + (params.durationMinutes || 30) * 60000);

  const fmt = (d: Date) =>
    d
      .toISOString()
      .replace(/[-:]/g, '')
      .replace(/\.\d{3}/, '');

  const url = new URL('https://calendar.google.com/calendar/render');
  url.searchParams.set('action', 'TEMPLATE');
  url.searchParams.set('text', params.title);
  url.searchParams.set('dates', `${fmt(start)}/${fmt(end)}`);
  url.searchParams.set('details', params.details);
  if (params.location) {
    url.searchParams.set('location', params.location);
  }
  return url.toString();
}

// Download a native .ics calendar file (opens in Apple Calendar, Google Calendar, Outlook on phone/desktop with native alarm)
export function downloadIcsReminder(reminder: {
  title: string;
  note: string;
  remindAt: string;
  businessName: string;
  leadPhone: string;
}) {
  const start = new Date(reminder.remindAt);
  const end = new Date(start.getTime() + 30 * 60000);
  const fmt = (d: Date) =>
    d
      .toISOString()
      .replace(/[-:]/g, '')
      .replace(/\.\d{3}/, '');

  const description = `Lead: ${reminder.businessName}\\nPhone: ${reminder.leadPhone}\\nNote: ${(reminder.note || '').replace(/\n/g, '\\n')}`;

  const ics = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//LeadFlow CRM//EN',
    'BEGIN:VEVENT',
    `UID:leadflow-${Date.now()}@leadflow.io`,
    `DTSTAMP:${fmt(new Date())}`,
    `DTSTART:${fmt(start)}`,
    `DTEND:${fmt(end)}`,
    `SUMMARY:${reminder.title}`,
    `DESCRIPTION:${description}`,
    'BEGIN:VALARM',
    'TRIGGER:-PT15M',
    'ACTION:DISPLAY',
    'DESCRIPTION:LeadFlow Call/Meeting Reminder',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');

  const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${reminder.businessName.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_reminder.ics`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Play pleasant dual-tone chime using Web Audio API (no external audio file required)
export function playNotificationChime() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    const playTone = (freq: number, startTime: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.001, startTime);
      gain.gain.exponentialRampToValueAtTime(0.18, startTime + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + duration);
    };

    const now = ctx.currentTime;
    playTone(587.33, now, 0.22); // D5
    playTone(880.0, now + 0.18, 0.35); // A5
  } catch {
    // ignore if browser blocks autoplay before interaction
  }
}

// Fire browser / PWA lock-screen notification
export async function triggerBrowserPushNotification(title: string, body: string) {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'default') {
    await Notification.requestPermission();
  }
  if (Notification.permission === 'granted') {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg && 'showNotification' in reg) {
        await reg.showNotification(title, {
          body,
          icon: '/icon.svg',
          badge: '/icon.svg',
        });
        return true;
      }
    }
    new Notification(title, { body, icon: '/icon.svg' });
    return true;
  }
  return false;
}

export function formatRelativeTime(isoString?: string | null): string {
  if (!isoString) return '—';
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return isoString;
  const diffMs = date.getTime() - Date.now();
  const absMins = Math.round(Math.abs(diffMs) / 60000);

  if (absMins < 1) return 'Just now';
  if (absMins < 60) {
    return diffMs < 0 ? `${absMins}m ago` : `in ${absMins}m`;
  }
  const absHours = Math.round(absMins / 60);
  if (absHours < 24) {
    return diffMs < 0 ? `${absHours}h ago` : `in ${absHours}h`;
  }
  const absDays = Math.round(absHours / 24);
  return diffMs < 0 ? `${absDays}d ago` : `in ${absDays}d`;
}
